﻿namespace TIPIS
{
    partial class Stabform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OneMore = new System.Windows.Forms.Button();
            this.Middle = new System.Windows.Forms.TextBox();
            this.MiddleText = new System.Windows.Forms.Label();
            this.DispersionText = new System.Windows.Forms.Label();
            this.StOtklText = new System.Windows.Forms.Label();
            this.StOtkl = new System.Windows.Forms.TextBox();
            this.Dispersion = new System.Windows.Forms.TextBox();
            this.Output = new System.Windows.Forms.Label();
            this.Output2 = new System.Windows.Forms.Label();
            this.Dispersion2 = new System.Windows.Forms.TextBox();
            this.StOtkl2 = new System.Windows.Forms.TextBox();
            this.Middle2 = new System.Windows.Forms.TextBox();
            this.Output3 = new System.Windows.Forms.Label();
            this.Dispersion3 = new System.Windows.Forms.TextBox();
            this.StOtkl3 = new System.Windows.Forms.TextBox();
            this.Middle3 = new System.Windows.Forms.TextBox();
            this.Output4 = new System.Windows.Forms.Label();
            this.Dispersion4 = new System.Windows.Forms.TextBox();
            this.StOtkl4 = new System.Windows.Forms.TextBox();
            this.Middle4 = new System.Windows.Forms.TextBox();
            this.Output5 = new System.Windows.Forms.Label();
            this.Dispersion5 = new System.Windows.Forms.TextBox();
            this.StOtkl5 = new System.Windows.Forms.TextBox();
            this.Middle5 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // OneMore
            // 
            this.OneMore.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.OneMore.Location = new System.Drawing.Point(13, 13);
            this.OneMore.Name = "OneMore";
            this.OneMore.Size = new System.Drawing.Size(100, 30);
            this.OneMore.TabIndex = 0;
            this.OneMore.Text = "Рассчитать";
            this.OneMore.UseVisualStyleBackColor = true;
            this.OneMore.Click += new System.EventHandler(this.OneMore_Click);
            // 
            // Middle
            // 
            this.Middle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Middle.Location = new System.Drawing.Point(200, 64);
            this.Middle.Name = "Middle";
            this.Middle.Size = new System.Drawing.Size(86, 23);
            this.Middle.TabIndex = 1;
            // 
            // MiddleText
            // 
            this.MiddleText.AutoSize = true;
            this.MiddleText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MiddleText.Location = new System.Drawing.Point(13, 67);
            this.MiddleText.Name = "MiddleText";
            this.MiddleText.Size = new System.Drawing.Size(182, 17);
            this.MiddleText.TabIndex = 2;
            this.MiddleText.Text = "Среднее арифметическое";
            // 
            // DispersionText
            // 
            this.DispersionText.AutoSize = true;
            this.DispersionText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DispersionText.Location = new System.Drawing.Point(13, 97);
            this.DispersionText.Name = "DispersionText";
            this.DispersionText.Size = new System.Drawing.Size(81, 17);
            this.DispersionText.TabIndex = 3;
            this.DispersionText.Text = "Дисперсия";
            // 
            // StOtklText
            // 
            this.StOtklText.AutoSize = true;
            this.StOtklText.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StOtklText.Location = new System.Drawing.Point(13, 127);
            this.StOtklText.Name = "StOtklText";
            this.StOtklText.Size = new System.Drawing.Size(177, 17);
            this.StOtklText.TabIndex = 4;
            this.StOtklText.Text = "Стандартное отклонение";
            // 
            // StOtkl
            // 
            this.StOtkl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StOtkl.Location = new System.Drawing.Point(200, 124);
            this.StOtkl.Name = "StOtkl";
            this.StOtkl.Size = new System.Drawing.Size(86, 23);
            this.StOtkl.TabIndex = 5;
            // 
            // Dispersion
            // 
            this.Dispersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dispersion.Location = new System.Drawing.Point(200, 94);
            this.Dispersion.Name = "Dispersion";
            this.Dispersion.Size = new System.Drawing.Size(86, 23);
            this.Dispersion.TabIndex = 6;
            // 
            // Output
            // 
            this.Output.AutoSize = true;
            this.Output.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Output.Location = new System.Drawing.Point(13, 157);
            this.Output.Name = "Output";
            this.Output.Size = new System.Drawing.Size(70, 17);
            this.Output.TabIndex = 7;
            this.Output.Text = "Вывод 1: ";
            // 
            // Output2
            // 
            this.Output2.AutoSize = true;
            this.Output2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Output2.Location = new System.Drawing.Point(13, 187);
            this.Output2.Name = "Output2";
            this.Output2.Size = new System.Drawing.Size(70, 17);
            this.Output2.TabIndex = 11;
            this.Output2.Text = "Вывод 2: ";
            // 
            // Dispersion2
            // 
            this.Dispersion2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dispersion2.Location = new System.Drawing.Point(292, 94);
            this.Dispersion2.Name = "Dispersion2";
            this.Dispersion2.Size = new System.Drawing.Size(90, 23);
            this.Dispersion2.TabIndex = 10;
            // 
            // StOtkl2
            // 
            this.StOtkl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StOtkl2.Location = new System.Drawing.Point(292, 124);
            this.StOtkl2.Name = "StOtkl2";
            this.StOtkl2.Size = new System.Drawing.Size(90, 23);
            this.StOtkl2.TabIndex = 9;
            // 
            // Middle2
            // 
            this.Middle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Middle2.Location = new System.Drawing.Point(292, 64);
            this.Middle2.Name = "Middle2";
            this.Middle2.Size = new System.Drawing.Size(90, 23);
            this.Middle2.TabIndex = 8;
            // 
            // Output3
            // 
            this.Output3.AutoSize = true;
            this.Output3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Output3.Location = new System.Drawing.Point(13, 217);
            this.Output3.Name = "Output3";
            this.Output3.Size = new System.Drawing.Size(70, 17);
            this.Output3.TabIndex = 15;
            this.Output3.Text = "Вывод 3: ";
            // 
            // Dispersion3
            // 
            this.Dispersion3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dispersion3.Location = new System.Drawing.Point(388, 94);
            this.Dispersion3.Name = "Dispersion3";
            this.Dispersion3.Size = new System.Drawing.Size(90, 23);
            this.Dispersion3.TabIndex = 14;
            // 
            // StOtkl3
            // 
            this.StOtkl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StOtkl3.Location = new System.Drawing.Point(388, 124);
            this.StOtkl3.Name = "StOtkl3";
            this.StOtkl3.Size = new System.Drawing.Size(90, 23);
            this.StOtkl3.TabIndex = 13;
            // 
            // Middle3
            // 
            this.Middle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Middle3.Location = new System.Drawing.Point(388, 64);
            this.Middle3.Name = "Middle3";
            this.Middle3.Size = new System.Drawing.Size(90, 23);
            this.Middle3.TabIndex = 12;
            // 
            // Output4
            // 
            this.Output4.AutoSize = true;
            this.Output4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Output4.Location = new System.Drawing.Point(13, 247);
            this.Output4.Name = "Output4";
            this.Output4.Size = new System.Drawing.Size(70, 17);
            this.Output4.TabIndex = 19;
            this.Output4.Text = "Вывод 4: ";
            // 
            // Dispersion4
            // 
            this.Dispersion4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dispersion4.Location = new System.Drawing.Point(484, 94);
            this.Dispersion4.Name = "Dispersion4";
            this.Dispersion4.Size = new System.Drawing.Size(90, 23);
            this.Dispersion4.TabIndex = 18;
            // 
            // StOtkl4
            // 
            this.StOtkl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StOtkl4.Location = new System.Drawing.Point(484, 124);
            this.StOtkl4.Name = "StOtkl4";
            this.StOtkl4.Size = new System.Drawing.Size(90, 23);
            this.StOtkl4.TabIndex = 17;
            // 
            // Middle4
            // 
            this.Middle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Middle4.Location = new System.Drawing.Point(484, 64);
            this.Middle4.Name = "Middle4";
            this.Middle4.Size = new System.Drawing.Size(90, 23);
            this.Middle4.TabIndex = 16;
            // 
            // Output5
            // 
            this.Output5.AutoSize = true;
            this.Output5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Output5.Location = new System.Drawing.Point(13, 277);
            this.Output5.Name = "Output5";
            this.Output5.Size = new System.Drawing.Size(70, 17);
            this.Output5.TabIndex = 23;
            this.Output5.Text = "Вывод 5: ";
            // 
            // Dispersion5
            // 
            this.Dispersion5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Dispersion5.Location = new System.Drawing.Point(580, 94);
            this.Dispersion5.Name = "Dispersion5";
            this.Dispersion5.Size = new System.Drawing.Size(90, 23);
            this.Dispersion5.TabIndex = 22;
            // 
            // StOtkl5
            // 
            this.StOtkl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.StOtkl5.Location = new System.Drawing.Point(580, 124);
            this.StOtkl5.Name = "StOtkl5";
            this.StOtkl5.Size = new System.Drawing.Size(90, 23);
            this.StOtkl5.TabIndex = 21;
            // 
            // Middle5
            // 
            this.Middle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Middle5.Location = new System.Drawing.Point(580, 64);
            this.Middle5.Name = "Middle5";
            this.Middle5.Size = new System.Drawing.Size(90, 23);
            this.Middle5.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(228, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 24;
            this.label1.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(326, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 25;
            this.label2.Text = "2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(424, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 17);
            this.label3.TabIndex = 26;
            this.label3.Text = "3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(515, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 17);
            this.label4.TabIndex = 27;
            this.label4.Text = "4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(614, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 17);
            this.label5.TabIndex = 28;
            this.label5.Text = "5";
            // 
            // Stabform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(704, 322);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Output5);
            this.Controls.Add(this.Dispersion5);
            this.Controls.Add(this.StOtkl5);
            this.Controls.Add(this.Middle5);
            this.Controls.Add(this.Output4);
            this.Controls.Add(this.Dispersion4);
            this.Controls.Add(this.StOtkl4);
            this.Controls.Add(this.Middle4);
            this.Controls.Add(this.Output3);
            this.Controls.Add(this.Dispersion3);
            this.Controls.Add(this.StOtkl3);
            this.Controls.Add(this.Middle3);
            this.Controls.Add(this.Output2);
            this.Controls.Add(this.Dispersion2);
            this.Controls.Add(this.StOtkl2);
            this.Controls.Add(this.Middle2);
            this.Controls.Add(this.Output);
            this.Controls.Add(this.Dispersion);
            this.Controls.Add(this.StOtkl);
            this.Controls.Add(this.StOtklText);
            this.Controls.Add(this.DispersionText);
            this.Controls.Add(this.MiddleText);
            this.Controls.Add(this.Middle);
            this.Controls.Add(this.OneMore);
            this.Name = "Stabform";
            this.Text = "Stabform";
            this.Load += new System.EventHandler(this.Stabform_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button OneMore;
        private System.Windows.Forms.TextBox Middle;
        private System.Windows.Forms.Label MiddleText;
        private System.Windows.Forms.Label DispersionText;
        private System.Windows.Forms.Label StOtklText;
        private System.Windows.Forms.TextBox StOtkl;
        private System.Windows.Forms.TextBox Dispersion;
        private System.Windows.Forms.Label Output;
        private System.Windows.Forms.Label Output2;
        private System.Windows.Forms.TextBox Dispersion2;
        private System.Windows.Forms.TextBox StOtkl2;
        private System.Windows.Forms.TextBox Middle2;
        private System.Windows.Forms.Label Output3;
        private System.Windows.Forms.TextBox Dispersion3;
        private System.Windows.Forms.TextBox StOtkl3;
        private System.Windows.Forms.TextBox Middle3;
        private System.Windows.Forms.Label Output4;
        private System.Windows.Forms.TextBox Dispersion4;
        private System.Windows.Forms.TextBox StOtkl4;
        private System.Windows.Forms.TextBox Middle4;
        private System.Windows.Forms.Label Output5;
        private System.Windows.Forms.TextBox Dispersion5;
        private System.Windows.Forms.TextBox StOtkl5;
        private System.Windows.Forms.TextBox Middle5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}