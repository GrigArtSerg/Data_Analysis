﻿namespace TIPIS
{
    partial class Optform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.C1 = new System.Windows.Forms.TextBox();
            this.C2 = new System.Windows.Forms.TextBox();
            this.a11 = new System.Windows.Forms.TextBox();
            this.a21 = new System.Windows.Forms.TextBox();
            this.a12 = new System.Windows.Forms.TextBox();
            this.l1 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.l11 = new System.Windows.Forms.Label();
            this.l21 = new System.Windows.Forms.Label();
            this.l12 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.MaxP = new System.Windows.Forms.Label();
            this.MaxXY = new System.Windows.Forms.Label();
            this.lb2 = new System.Windows.Forms.Label();
            this.lb1 = new System.Windows.Forms.Label();
            this.b2 = new System.Windows.Forms.TextBox();
            this.b1 = new System.Windows.Forms.TextBox();
            this.l22 = new System.Windows.Forms.Label();
            this.a22 = new System.Windows.Forms.TextBox();
            this.count = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // C1
            // 
            this.C1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.C1.Location = new System.Drawing.Point(13, 13);
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(100, 26);
            this.C1.TabIndex = 0;
            this.C1.Text = "350";
            // 
            // C2
            // 
            this.C2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.C2.Location = new System.Drawing.Point(13, 45);
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(100, 26);
            this.C2.TabIndex = 1;
            this.C2.Text = "500";
            // 
            // a11
            // 
            this.a11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.a11.Location = new System.Drawing.Point(13, 77);
            this.a11.Name = "a11";
            this.a11.Size = new System.Drawing.Size(100, 26);
            this.a11.TabIndex = 2;
            this.a11.Text = "50";
            // 
            // a21
            // 
            this.a21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.a21.Location = new System.Drawing.Point(13, 109);
            this.a21.Name = "a21";
            this.a21.Size = new System.Drawing.Size(100, 26);
            this.a21.TabIndex = 3;
            this.a21.Text = "80";
            // 
            // a12
            // 
            this.a12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.a12.Location = new System.Drawing.Point(159, 77);
            this.a12.Name = "a12";
            this.a12.Size = new System.Drawing.Size(100, 26);
            this.a12.TabIndex = 4;
            this.a12.Text = "70";
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l1.Location = new System.Drawing.Point(119, 16);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(29, 20);
            this.l1.TabIndex = 5;
            this.l1.Text = "C1";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l2.Location = new System.Drawing.Point(119, 48);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(29, 20);
            this.l2.TabIndex = 6;
            this.l2.Text = "C2";
            // 
            // l11
            // 
            this.l11.AutoSize = true;
            this.l11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l11.Location = new System.Drawing.Point(119, 80);
            this.l11.Name = "l11";
            this.l11.Size = new System.Drawing.Size(36, 20);
            this.l11.TabIndex = 7;
            this.l11.Text = "a11";
            // 
            // l21
            // 
            this.l21.AutoSize = true;
            this.l21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l21.Location = new System.Drawing.Point(118, 112);
            this.l21.Name = "l21";
            this.l21.Size = new System.Drawing.Size(36, 20);
            this.l21.TabIndex = 8;
            this.l21.Text = "a21";
            // 
            // l12
            // 
            this.l12.AutoSize = true;
            this.l12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l12.Location = new System.Drawing.Point(265, 80);
            this.l12.Name = "l12";
            this.l12.Size = new System.Drawing.Size(36, 20);
            this.l12.TabIndex = 9;
            this.l12.Text = "a12";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(12, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(339, 20);
            this.label6.TabIndex = 10;
            this.label6.Text = "P = C1*X+C2*Y – максимизируемая функция";
            // 
            // MaxP
            // 
            this.MaxP.AutoSize = true;
            this.MaxP.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MaxP.Location = new System.Drawing.Point(12, 255);
            this.MaxP.Name = "MaxP";
            this.MaxP.Size = new System.Drawing.Size(224, 20);
            this.MaxP.TabIndex = 11;
            this.MaxP.Text = "Максимальное значение P =\r\n";
            // 
            // MaxXY
            // 
            this.MaxXY.AutoSize = true;
            this.MaxXY.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MaxXY.Location = new System.Drawing.Point(12, 278);
            this.MaxXY.Name = "MaxXY";
            this.MaxXY.Size = new System.Drawing.Size(196, 20);
            this.MaxXY.TabIndex = 12;
            this.MaxXY.Text = "достигается при X и Y ...";
            // 
            // lb2
            // 
            this.lb2.AutoSize = true;
            this.lb2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb2.Location = new System.Drawing.Point(265, 48);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(27, 20);
            this.lb2.TabIndex = 16;
            this.lb2.Text = "b2";
            // 
            // lb1
            // 
            this.lb1.AutoSize = true;
            this.lb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb1.Location = new System.Drawing.Point(265, 16);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(27, 20);
            this.lb1.TabIndex = 15;
            this.lb1.Text = "b1";
            // 
            // b2
            // 
            this.b2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.b2.Location = new System.Drawing.Point(159, 45);
            this.b2.Name = "b2";
            this.b2.Size = new System.Drawing.Size(100, 26);
            this.b2.TabIndex = 14;
            this.b2.Text = "9000";
            // 
            // b1
            // 
            this.b1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.b1.Location = new System.Drawing.Point(159, 13);
            this.b1.Name = "b1";
            this.b1.Size = new System.Drawing.Size(100, 26);
            this.b1.TabIndex = 13;
            this.b1.Text = "5000";
            // 
            // l22
            // 
            this.l22.AutoSize = true;
            this.l22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.l22.Location = new System.Drawing.Point(265, 112);
            this.l22.Name = "l22";
            this.l22.Size = new System.Drawing.Size(36, 20);
            this.l22.TabIndex = 18;
            this.l22.Text = "a22";
            // 
            // a22
            // 
            this.a22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.a22.Location = new System.Drawing.Point(159, 109);
            this.a22.Name = "a22";
            this.a22.Size = new System.Drawing.Size(100, 26);
            this.a22.TabIndex = 17;
            this.a22.Text = "90";
            // 
            // count
            // 
            this.count.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.count.Location = new System.Drawing.Point(12, 304);
            this.count.Name = "count";
            this.count.Size = new System.Drawing.Size(230, 28);
            this.count.TabIndex = 19;
            this.count.Text = "Рассчитать максимизацию";
            this.count.UseVisualStyleBackColor = true;
            this.count.Click += new System.EventHandler(this.count_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label1.Location = new System.Drawing.Point(12, 184);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 20);
            this.label1.TabIndex = 20;
            this.label1.Text = "a11*X+a12*Y<=b1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label2.Location = new System.Drawing.Point(12, 209);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 20);
            this.label2.TabIndex = 21;
            this.label2.Text = "a21*X+a22*Y<=b2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label3.Location = new System.Drawing.Point(13, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(355, 20);
            this.label3.TabIndex = 22;
            this.label3.Text = "Система для рассчета области ограничений:";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label4.Location = new System.Drawing.Point(307, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(607, 23);
            this.label4.TabIndex = 23;
            this.label4.Text = "C1 – стоимость мелкоформатных книг, С2 – стоимость крупноформатных книг ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label5.Location = new System.Drawing.Point(12, 232);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(688, 20);
            this.label5.TabIndex = 24;
            this.label5.Text = "X – количество мелкоформатных книг, Y – количество крупнформатных книг, P – выруч" +
    "ка";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label7.Location = new System.Drawing.Point(307, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(621, 20);
            this.label7.TabIndex = 25;
            this.label7.Text = "a11/a12 - необходимо бумаги для печати одной мелко/крупно- форматной книги";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label8.Location = new System.Drawing.Point(307, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(624, 20);
            this.label8.TabIndex = 26;
            this.label8.Text = "a21/a22 - необходимо чернил для печати одной мелко/крупно- форматной книги";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.label9.Location = new System.Drawing.Point(307, 48);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(536, 20);
            this.label9.TabIndex = 27;
            this.label9.Text = "b1 – количество бумаги на складе, b2 – количество чернил на складе";
            // 
            // Optform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(945, 406);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.count);
            this.Controls.Add(this.l22);
            this.Controls.Add(this.a22);
            this.Controls.Add(this.lb2);
            this.Controls.Add(this.lb1);
            this.Controls.Add(this.b2);
            this.Controls.Add(this.b1);
            this.Controls.Add(this.MaxXY);
            this.Controls.Add(this.MaxP);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.l12);
            this.Controls.Add(this.l21);
            this.Controls.Add(this.l11);
            this.Controls.Add(this.l2);
            this.Controls.Add(this.l1);
            this.Controls.Add(this.a12);
            this.Controls.Add(this.a21);
            this.Controls.Add(this.a11);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.C1);
            this.Name = "Optform";
            this.Text = "Optform";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox C1;
        private System.Windows.Forms.TextBox C2;
        private System.Windows.Forms.TextBox a11;
        private System.Windows.Forms.TextBox a21;
        private System.Windows.Forms.TextBox a12;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Label l11;
        private System.Windows.Forms.Label l21;
        private System.Windows.Forms.Label l12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label MaxP;
        private System.Windows.Forms.Label MaxXY;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.TextBox b2;
        private System.Windows.Forms.TextBox b1;
        private System.Windows.Forms.Label l22;
        private System.Windows.Forms.TextBox a22;
        private System.Windows.Forms.Button count;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}